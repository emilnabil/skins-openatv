# -*- coding: utf-8 -*-
# Skin SmooGemini Mod
# Final Version: Renamed to SmooGemini

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import ActionMap
from Components.config import (
    config, configfile, ConfigSubsection, getConfigListEntry,
    ConfigSelection
)
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.AVSwitch import AVSwitch
from Tools.Directories import fileExists
from enigma import ePicLoad
import os
import re

# --- دوال المساعدة والترجمة ---
try:
    from . import _
except ImportError:
    def _(txt): return txt

def get_lang():
    try: return config.osd.language.value
    except: return 'en_EN'

IS_ARABIC = 'ar' in get_lang().lower()

def T(eng_txt, ar_txt):
    return ar_txt if IS_ARABIC else eng_txt

version = "1.0"

# =========================================================================
# 1. تعريف الإعدادات
# =========================================================================
config.plugins.Smoo = ConfigSubsection()

# --- قوائم الألوان ---
COLOR_CHOICES = [
    ('#ffffff', T('White', 'أبيض')),
    ('#e7e412', T('Yellow', 'أصفر')),
    ('#ff4a3c', T('Red', 'أحمر')),
    ('#22539e', T('Blue', 'أزرق')),
    ('#32CD32', T('Green', 'أخضر')),
    ('#fcc000', T('Orange', 'برتقالي')),
    ('#00FFFF', T('Cyan', 'سماوي')),
    ('#E799A3', T('Pink', 'وردي')),
    ('#000000', T('Black', 'أسود')),
    ('#808080', T('Grey', 'رمادي')),
    ('#FFD700', T('Gold', 'ذهبي')),
    ('#008080', T('Teal', 'فيروزي غامق')),
    ('#40E0D0', T('Turquoise', 'تركواز')),
    ('#800080', T('Purple', 'بنفسجي')),
    ('#FF00FF', T('Magenta', 'فوشي')),
    ('#C0C0C0', T('Silver', 'فضي')),
    ('#1b3c85', T('Dark Blue BG', 'خلفية زرقاء'))
]

BACKGROUND_CHOICES = [
    ('#1b3c85', T('Default Blue', 'أزرق افتراضي')),
    ('#151311', T('Black', 'أسود')),
    ('#800000', T('Red', 'أحمر')),
    ('#275918', T('Green', 'أخضر')),
    ('#43494D', T('Grey', 'رمادي')),
    ('#013C66', T('Dark Blue', 'أزرق داكن')),
    ('#5e1a67', T('Purple', 'بنفسجي')),
    ('#151312', T('Orange', 'برتقالي'))
]

# --- إعدادات المظهر ---
config.plugins.Smoo.colorSelector = ConfigSelection(default='head', choices=[
 ('head', T('Default', 'الافتراضي')),
 ('color1_Red', T('Red Style', 'أحمر')),
 ('color2_Green', T('Green Style', 'أخضر')),
 ('color3_Grey', T('Grey Style', 'رمادي')),
 ('color4_Blue', T('Blue Style', 'أزرق')),
 ('color5_Green2', T('Forest Style', 'غابة')),
 ('color6_Brown', T('Brown Style', 'بني')),
 ('color7_Dark Purple', T('Purple Style', 'بنفسجي')),
 ('color8_Dark Red', T('Dark Red Style', 'أحمر داكن')),
 ('color9_Orange', T('Orange Style', 'برتقالي')),
 ('color10_Grey2', T('Dark Grey Style', 'رمادي داكن')),
 ('color11_Oily', T('Oily Style', 'زيتي')),
 ('color12_Black', T('Black Style', 'أسود'))
])

config.plugins.Smoo.skinSelector = ConfigSelection(default='base', choices=[
 ('base', T('Default Base', 'القاعدة الافتراضية'))
])

config.plugins.Smoo.FontStyle = ConfigSelection(default='basic', choices=[
 ('basic', T('Default Font', 'الخط الافتراضي')),
 ('font1', 'Verdana'), ('font2', 'Cravelo'), ('font3', 'Mongule'),
 ('font4', 'Tenada'), ('font5', 'HandelGotDBol'), ('font6', 'Fury'),
 ('font7', 'Joyful'), ('font8', 'Nexa'), ('font9', 'Tommy'), ('font10', 'Poetsen One')
])

config.plugins.Smoo.FontScale = ConfigSelection(default='93', choices=[
 ('93', '100%'), ('80', '80%'), ('90', '90%'), ('100', '100%'), ('110', '110%'), ('120', '120%')
]) 

config.plugins.Smoo.transparency = ConfigSelection(default='06', choices=[
 ('06', T('Default', 'افتراضي')), ('10', '10%'), ('20', '20%'), ('40', '40%'), ('00', T('None', 'لا يوجد'))
])

# --- أنماط الشاشات ---
config.plugins.Smoo.InfobarStyle = ConfigSelection(default='infobar_no_posters', choices=[
 ('infobar_no_posters', T('Simple', 'بسيط')),
 ('infobar_2_posters', T('2 Posters', 'بوسترين 2')),
 ('infobar_3_posters', T('3 Posters', '3 بوسترات')),
 ('infobar_mini', T('Mini Bar', 'بار مصغر')),
 ('infobar_mini_2', T('Mini Bar 2', 'بار مصغر 2')),
 ('infobar_round', T('Round', 'دائري')),
 ('infobar_2_round', T('Round 2', 'دائري 2')),
 ('infobar2_no_posters', 'Style 2 Simple'),
 ('infobar2_2_posters', 'Style 2 (2 Posters)'),
 ('infobar2_3_posters', 'Style 2 (3 Posters)'),
 ('infobar2_3_backdrop', 'Style 2 Backdrop'),
 ('infobar3_no_posters', 'Style 3 Simple'),
 ('infobar3_2_posters', 'Style 3 (2 Posters)'),
 ('infobar3_2_backdrop', 'Style 3 Backdrop'),
 ('infobar3_3_posters', 'Style 3 (3 Posters)'),
 ('infobar3_no_posters_black', 'Style 3 Black Simple'),
 ('infobar3_2_posters_black', 'Style 3 Black (2 Posters)'),
 ('infobar3_3_posters_black', 'Style 3 Black (3 Posters)'),
 ('infobar3_2_backdrop_black', 'Style 3 Black Backdrop'),
 ('infobar4_no_posters', 'Style 4 Simple'),
 ('infobar4_1_posters', 'Style 4 (1 Poster)'),
 ('infobar4_3_posters', 'Style 4 (3 Posters)'),
 ('infobar4_backdrop', 'Style 4 Backdrop'),
 ('infobar5_no_posters', 'Style 5 Simple'),
 ('infobar5_2_posters', 'Style 5 (2 Posters)'),
 ('infobar5_3_posters', 'Style 5 (3 Posters)'),
 ('infobar5_star_3_posters', 'Style 5 Star')
])

config.plugins.Smoo.SecondInfobarStyle = ConfigSelection(default='secondinfobar_no_posters', choices=[
 ('secondinfobar_no_posters', T('No Posters', 'بدون بوسترات')),
 ('secondinfobar_posters', T('With Posters', 'مع بوسترات')),
 ('secondinfobar2_no_posters', 'Style 2 Simple'),
 ('secondinfobar2_posters', 'Style 2 With Posters'),
 ('secondinfobar3_no_posters', 'Style 3 Simple'),
 ('secondinfobar3_posters', 'Style 3 With Posters'),
 ('secondinfobar4_no_posters', 'Style 4 Simple'),
 ('secondinfobar4_posters', 'Style 4 With Posters'),
 ('secondinfobar5_signal', 'Signal Bar')
])

config.plugins.Smoo.ChannSelector = ConfigSelection(default='channellist_no_posters', choices=[
 ('channellist_no_posters', T('No Posters', 'بدون بوسترات')),
 ('channellist_5_posters', T('5 Posters', '5 بوسترات')),
 ('channellist_5_backdrop', T('5 Backdrops', '5 باك دروب')),
 ('channellist2_no_posters', T('Style 2 Simple', 'ستايل 2 بسيط')),
 ('channellist2_1_posters', T('Style 2 (1 Poster)', 'ستايل 2 (1 بوستر)')),
 ('channellist2_3_posters', T('Style 2 (3 Posters)', 'ستايل 2 (3 بوسترات)')),
 ('channellist2_4_posters', T('Style 2 (4 Posters)', 'ستايل 2 (4 بوسترات)')),
 ('channellist2_6_posters', T('Style 2 (6 Posters)', 'ستايل 2 (6 بوسترات)')),
 ('channellist2_12_posters', T('Style 2 (12 Posters)', 'ستايل 2 (12 بوستر)'))
])

config.plugins.Smoo.EventView = ConfigSelection(default='eventview_no_posters', choices=[
 ('eventview_no_posters', T('No Posters', 'بدون بوسترات')),
 ('eventview_7_posters', T('7 Posters', '7 بوسترات')),
 ('eventview_11_posters', T('11 Posters', '11 بوستر')),
 ('eventview_12_posters', T('12 Posters', '12 بوستر'))
])

config.plugins.Smoo.EPGSelection = ConfigSelection(default='epgselection_no_posters', choices=[
 ('epgselection_no_posters', 'No Posters'),
 ('epgselection_1_posters', '1 Poster')
])

config.plugins.Smoo.VolumeBar = ConfigSelection(default='volume', choices=[
 ('volume', 'Style 1'), ('volume2', 'Style 2'), ('volume3', 'Style 3'), ('volume4', 'Style 4')
])

config.plugins.Smoo.ChannForegroundColor = ConfigSelection(default='#ffffff', choices=COLOR_CHOICES)
config.plugins.Smoo.ChannForegroundColorSelected = ConfigSelection(default='white', choices=COLOR_CHOICES)
config.plugins.Smoo.ChannServiceDescriptionColor = ConfigSelection(default='#49bbff', choices=COLOR_CHOICES)
config.plugins.Smoo.ChannServiceDescriptionColorSelected = ConfigSelection(default='#a1daff', choices=COLOR_CHOICES)
config.plugins.Smoo.ChannBackgroundColorSelected = ConfigSelection(default='#1b3c85', choices=BACKGROUND_CHOICES)


# =========================================================================
# 2. الدالة الرئيسية
# =========================================================================
def Plugins(**kwargs):
    return PluginDescriptor(
        name='Setup Smoo v.%s' % version,
        description=T('SmooGemini Skin Mod', 'مود سكين SmooGemini'),
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon='plugin.png',
        fnc=main
    )

def main(session, **kwargs):
    session.open(SmooSetup)

# --- دالة الحقن التلقائي للترجمة ---
def apply_translation_fixes(content):
    if not content or not isinstance(content, str):
        return content
    try:
        # 1. استبدال المصدر القياسي (EventName)
        content = content.replace('type="EventName">Name', 'type="GeminiEvent">Name')
        content = content.replace('type="EventName">FullDescription', 'type="GeminiEvent">FullDescription')
        content = content.replace('type="EventName">ExtendedDescription', 'type="GeminiEvent">FullDescription')
        content = content.replace('type="EventName">ShortDescription', 'type="GeminiEvent">FullDescription')

        # 2. استبدال حالات خاصة بـ EventView
        content = re.sub(r'(<widget[^>]*source="Event"[^>]*>.*?<convert type=")EventName(">Name</convert>)', r'\1GeminiEvent\2', content, flags=re.DOTALL)
        
        content = re.sub(r'(<widget[^>]*source="Event"[^>]*>.*?<convert type=")EventName(">FullDescription</convert>)', r'\1GeminiEvent\2', content, flags=re.DOTALL)
        content = re.sub(r'(<widget[^>]*source="Event"[^>]*>.*?<convert type=")EventName(">ExtendedDescription</convert>)', r'\1GeminiEvent\2', content, flags=re.DOTALL)
        
        content = re.sub(r'(<widget[^>]*source="session\.Event_(Now|Next)"[^>]*>.*?<convert type=")EventName(">Name</convert>)', r'\1GeminiEvent\3', content, flags=re.DOTALL)

    except Exception as e:
        print("[SmooPlugin] Translate Injection Error:", e)
        
    return content

# --- دالة الألوان ---
def modify_channel_colors(content):
    if not content or not isinstance(content, str):
        return content
        
    try:
        fg = str(config.plugins.Smoo.ChannForegroundColor.value)
        fg_sel = str(config.plugins.Smoo.ChannForegroundColorSelected.value)
        desc = str(config.plugins.Smoo.ChannServiceDescriptionColor.value)
        desc_sel = str(config.plugins.Smoo.ChannServiceDescriptionColorSelected.value)
        bg_sel = str(config.plugins.Smoo.ChannBackgroundColorSelected.value)

        content = re.sub(r'foregroundColor="[^"]*"', f'foregroundColor="{fg}"', content)
        content = re.sub(r'foregroundColorSelected="[^"]*"', f'foregroundColorSelected="{fg_sel}"', content)
        content = re.sub(r'colorServiceDescription="[^"]*"', f'colorServiceDescription="{desc}"', content)
        content = re.sub(r'colorServiceDescriptionSelected="[^"]*"', f'colorServiceDescriptionSelected="{desc_sel}"', content)
        content = re.sub(r'backgroundColorSelected="[^"]*"', f'backgroundColorSelected="{bg_sel}"', content)
        
    except:
        pass
    return content

def _apply_scale_to_font_xml(xml_text, scale_value):
    return re.sub(r'scale="\d+"', f'scale="{scale_value}"', xml_text)

def _apply_transparency_to_header_color(xml_text, alpha_hex):
    if not re.match(r'^[0-9A-Fa-f]{2}$', (alpha_hex or '')): return xml_text
    def _repl(m): return f"{m.group(1)}{alpha_hex.upper()}{m.group(2)}{m.group(3)}"
    return re.sub(r'(<color\s+name="header"[^>]*?value="#)[0-9A-Fa-f]{2}([0-9A-Fa-f]{6})(")', _repl, xml_text, flags=re.IGNORECASE)

class SmooSetup(ConfigListScreen, Screen):
    skin = """
    <screen name="SmooSetup" position="center,center" size="1000,640" title="Smoo-FHD Plugin">
        <eLabel font="Regular; 24" foregroundColor="#ff4a3c" halign="center" position="20,598" size="120,26" text="{cancel_txt}" />
        <eLabel font="Regular; 24" foregroundColor="#32CD32" halign="center" position="220,598" size="120,26" text="{save_txt}" />
        <eLabel font="Regular; 24" foregroundColor="#22539e" halign="center" position="420,598" size="120,26" text="{info_txt}" />
        <widget name="Preview" position="997,690" size="498, 280" zPosition="1" />
        <widget name="config" font="Regular; 24" itemHeight="40" position="5,5" scrollbarMode="showOnDemand" size="990,550" />
    </screen>
    """.format(cancel_txt=T("Cancel", "إلغاء"), save_txt=T("Save", "حفظ"), info_txt=T("Info", "معلومات"))

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(T('SmooGemini Plugin v.%s', 'إعدادات SmooGemini إصدار %s') % version)
        self.session = session
        # تم تحديث المسار إلى الاسم الجديد SmooGemini
        self.skinFile = '/usr/share/enigma2/SmooGemini/skin.xml'
        self.previewFiles = '/usr/lib/enigma2/python/Plugins/Extensions/Smoo/sample/'
        self['Preview'] = Pixmap()
        
        list = []
        list.append(getConfigListEntry(T('Color Style:', 'نمط الألوان:'), config.plugins.Smoo.colorSelector))
        list.append(getConfigListEntry(T('Skin Style:', 'ستايل السكين:'), config.plugins.Smoo.skinSelector))
        list.append(getConfigListEntry(T('Select Your Font:', 'اختر الخط:'), config.plugins.Smoo.FontStyle))
        list.append(getConfigListEntry(T('Font Size:', 'حجم الخط:'), config.plugins.Smoo.FontScale))
        list.append(getConfigListEntry(T('Transparency:', 'الشفافية:'), config.plugins.Smoo.transparency))
        list.append(getConfigListEntry(T('InfoBar Style:', 'نمط إنفو بار:'), config.plugins.Smoo.InfobarStyle))
        list.append(getConfigListEntry(T('SecondInfobar Style:', 'نمط إنفو بار الثاني:'), config.plugins.Smoo.SecondInfobarStyle))
        list.append(getConfigListEntry(T('ChannelSelection Style:', 'نمط قائمة القنوات:'), config.plugins.Smoo.ChannSelector))
        list.append(getConfigListEntry(T('EventView Style:', 'نمط عرض الحدث:'), config.plugins.Smoo.EventView))
        list.append(getConfigListEntry(T('EPGSelection Style:', 'نمط دليل البرامج:'), config.plugins.Smoo.EPGSelection))
        list.append(getConfigListEntry(T('VolumeBar Style:', 'نمط الصوت:'), config.plugins.Smoo.VolumeBar))
        
        list.append(getConfigListEntry(T('--- Channel Colors ---', '--- ألوان القنوات ---'), config.plugins.Smoo.skinSelector))
        
        try:
            list.append(getConfigListEntry(T('Channel Text Color:', 'لون اسم القناة:'), config.plugins.Smoo.ChannForegroundColor))
            list.append(getConfigListEntry(T('Channel Selected Text:', 'لون القناة المختارة:'), config.plugins.Smoo.ChannForegroundColorSelected))
            list.append(getConfigListEntry(T('Description Color:', 'لون وصف الحدث:'), config.plugins.Smoo.ChannServiceDescriptionColor))
            list.append(getConfigListEntry(T('Description Selected:', 'لون الوصف المختار:'), config.plugins.Smoo.ChannServiceDescriptionColorSelected))
            list.append(getConfigListEntry(T('Selection Background:', 'لون خلفية الاختيار:'), config.plugins.Smoo.ChannBackgroundColorSelected))
        except: pass

        ConfigListScreen.__init__(self, list)
        self['actions'] = ActionMap(['OkCancelActions','DirectionActions','InputActions','ColorActions'], 
            {'left': self.keyLeft, 'down': self.keyDown, 'up': self.keyUp, 'right': self.keyRight,
            'red': self.keyExit, 'green': self.keySave, 'blue': self.info, 'cancel': self.keyExit}, -1)
        
        self.onLayoutFinish.append(self.UpdateComponents)
        self.PicLoad = ePicLoad()
        self.Scale = AVSwitch().getFramebufferScale()
        try: self.PicLoad.PictureData.get().append(self.DecodePicture)
        except: self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)

    def keySave(self):
        for x in self['config'].list: x[1].save()
        try:
            skin_lines = []
            
            head_file = self.previewFiles + 'head-' + config.plugins.Smoo.colorSelector.value + '.xml'
            if os.path.exists(head_file):
                with open(head_file, 'r') as f: _head = f.read()
                _head = _apply_transparency_to_header_color(_head, config.plugins.Smoo.transparency.value)
                skin_lines.append(_head)

            font_file = self.previewFiles + 'font-' + config.plugins.Smoo.FontStyle.value + '.xml'
            if os.path.exists(font_file):
                with open(font_file, 'r') as f: _font = f.read()
                _font = _apply_scale_to_font_xml(_font, config.plugins.Smoo.FontScale.value)
                skin_lines.append(_font)

            files_to_read = [
                'infobar-' + config.plugins.Smoo.InfobarStyle.value + '.xml',
                'secondinfobar-' + config.plugins.Smoo.SecondInfobarStyle.value + '.xml',
                'channellist-' + config.plugins.Smoo.ChannSelector.value + '.xml',
                'eventview-' + config.plugins.Smoo.EventView.value + '.xml',
                'epgselection-' + config.plugins.Smoo.EPGSelection.value + '.xml',
                'vol-' + config.plugins.Smoo.VolumeBar.value + '.xml'
            ]
            
            for fname in files_to_read:
                full_path = self.previewFiles + fname
                if os.path.exists(full_path):
                    with open(full_path, 'r') as f: content = f.read()
                    
                    # 1. الألوان
                    if 'channellist-' in fname:
                        content = modify_channel_colors(content)
                    
                    # 2. الترجمة
                    content = apply_translation_fixes(content)
                    
                    skin_lines.append(content)
            
            base_file = self.previewFiles + 'base.xml'
            if config.plugins.Smoo.skinSelector.value == 'base1':
                base_file = self.previewFiles + 'base1.xml'
            
            if os.path.exists(base_file):
                with open(base_file, 'r') as f:
                    content = f.read()
                    content = apply_translation_fixes(content)
                    skin_lines.append(content)

            with open(self.skinFile, 'w') as f: f.writelines(skin_lines)
                
        except Exception as e:
            self.session.open(MessageBox, T('Error: ', 'خطأ: ') + str(e), MessageBox.TYPE_ERROR)
            return

        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, T('Restart GUI now?', 'تم الحفظ. إعادة التشغيل الآن؟'), MessageBox.TYPE_YESNO)
        restartbox.setTitle(T('Restart GUI now?', 'إعادة التشغيل'))

    def restartGUI(self, answer):
        if answer is True:
            try:
                from Screens.Standby import TryQuitMainloop
                self.session.open(TryQuitMainloop, 3)
            except:
                self.close()
        else:
            self.close()

    def GetPicturePath(self):
        try:
            val = self['config'].getCurrent()[1].value
            path = self.previewFiles.replace('sample/', 'screens/') + val + '.png'
            return path if fileExists(path) else self.previewFiles.replace('sample/', 'screens/') + 'default.png'
        except: return self.previewFiles.replace('sample/', 'screens/') + 'default.png'

    def UpdatePicture(self):
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.onLayoutFinish.append(self.ShowPicture)

    def ShowPicture(self, data=None):
        if self["Preview"].instance:
            self.PicLoad.setPara([450, 250, self.Scale[0], self.Scale[1], 0, 1, "ff000000"])
            if self.PicLoad.startDecode(self.GetPicturePath()):
                self.PicLoad = ePicLoad()
                try: self.PicLoad.PictureData.get().append(self.DecodePicture)
                except: self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)

    def DecodePicture(self, PicInfo=None):
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["Preview"].instance.setPixmap(ptr)
            self["Preview"].instance.show()

    def UpdateComponents(self): self.UpdatePicture()
    def info(self): self.session.open(MessageBox, T('Setup Smoo for Smoo-FHD v.%s', 'إعدادات Smoo لسكين Smoo-FHD إصدار %s') % version, MessageBox.TYPE_INFO)
    def keyLeft(self): ConfigListScreen.keyLeft(self); self.ShowPicture()
    def keyRight(self): ConfigListScreen.keyRight(self); self.ShowPicture()
    def keyDown(self): self['config'].instance.moveSelection(self['config'].instance.moveDown); self.ShowPicture()
    def keyUp(self): self['config'].instance.moveSelection(self['config'].instance.moveUp); self.ShowPicture()
    def keyExit(self):
        for x in self['config'].list: x[1].cancel()
        self.close()