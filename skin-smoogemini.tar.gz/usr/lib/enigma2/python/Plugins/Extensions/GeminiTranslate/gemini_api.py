# -*- coding: utf-8 -*-
import os
import json
import codecs

# ملف الكاش المشترك مع السكين
CACHE_FILE = "/media/hdd/gemini_cache.json"

def get_api_key():
    try:
        with open("/usr/keys/gemini.key", 'r') as f:
            return f.read().strip()
    except:
        return None

def save_to_cache(original_title_key, final_title, final_desc):
    current_cache = {}
    if os.path.exists(CACHE_FILE):
        try:
            with codecs.open(CACHE_FILE, 'r', encoding='utf-8') as f:
                current_cache = json.load(f)
        except:
            current_cache = {}
    
    # نستخدم العنوان الأصلي (البلغاري) كمفتاح للبحث لاحقاً
    current_cache[original_title_key] = {
        "title": final_title,
        "desc": final_desc
    }
    
    try:
        with codecs.open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(current_cache, f, ensure_ascii=False, indent=4)
    except:
        pass

def get_translation(text_to_translate):
    API_KEY = get_api_key()
    if not API_KEY: return "Error: No API Key"

    # نحتفظ بالعنوان الأصلي (البلغاري) عشان نستخدمه كمفتاح للكاش
    original_title_key = text_to_translate.split('\n')[0].strip()
    
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + API_KEY
    
    safe_text = text_to_translate.replace('"', ' ').strip()

    # === التعديل هنا: نطلب منه صراحة يترجم العنوان للإنجليزي ===
    prompt = f"""
    Task: Translate TV event info.
    1. Title: Translate the title to Arabic AND English.
    2. Format Title line exactly like this: 'Arabic Title / English Title'
    3. Description: Translate full description to Arabic.
    4. Output format strictly: Title ||| Description
    
    Input text: {safe_text}
    """
    
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    json_file = "/tmp/gemini_manual_req.json"
    
    try:
        with codecs.open(json_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        
        cmd = f'curl -s -k --max-time 15 -H "Content-Type: application/json" -d @{json_file} "{url}"'
        stream = os.popen(cmd)
        output = stream.read()
        
        if os.path.exists(json_file): os.remove(json_file)

        if '"text":' in output:
            response = json.loads(output)
            raw_text = response['candidates'][0]['content']['parts'][0]['text'].strip()
            
            final_title = ""
            final_desc = ""

            if "|||" in raw_text:
                parts = raw_text.split("|||")
                final_title = parts[0].strip()
                final_desc = parts[1].strip()
            else:
                final_title = raw_text
                final_desc = raw_text
            
            # حفظ في الكاش (المفتاح هو الاسم البلغاري، والقيمة هي العربي/الإنجليزي)
            save_to_cache(original_title_key, final_title, final_desc)
            
            return f"{final_title}\n\n{final_desc}"
        else:
            return "Error: API Limit or No Response"

    except Exception as e:
        return f"Error: {str(e)}"