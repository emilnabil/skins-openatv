# -*- coding: utf-8 -*-
from __future__ import print_function, absolute_import
import os
import json
import sys

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

if PY2:
    text_type = unicode
    binary_type = str
    import codecs
    open_file = codecs.open
else:
    text_type = str
    binary_type = bytes
    open_file = open


CACHE_FILE = "/media/hdd/gemini_cache.json"

def get_api_key():
    try:
        with open_file("/usr/keys/gemini.key", 'r', encoding='utf-8') as f:
            api_key = f.read().strip()
            if PY2 and isinstance(api_key, text_type):
                api_key = api_key.encode('utf-8', 'ignore')
            return api_key
    except Exception as e:
        print("[GeminiAPI] Error reading API key:", str(e))
        return None

def save_to_cache(original_title_key, final_title, final_desc):
    current_cache = {}
    
    if PY2 and isinstance(original_title_key, binary_type):
        try:
            original_title_key = original_title_key.decode('utf-8', 'ignore')
        except:
            original_title_key = original_title_key.decode('latin-1', 'ignore')
    
    if os.path.exists(CACHE_FILE):
        try:
            with open_file(CACHE_FILE, 'r', encoding='utf-8') as f:
                current_cache = json.load(f)
        except Exception as e:
            print("[GeminiAPI] Error loading cache:", str(e))
            current_cache = {}
    
    if PY2:
        if isinstance(final_title, binary_type):
            final_title = final_title.decode('utf-8', 'ignore')
        if isinstance(final_desc, binary_type):
            final_desc = final_desc.decode('utf-8', 'ignore')
    
    current_cache[original_title_key] = {
        "title": final_title,
        "desc": final_desc
    }
    
    try:
        with open_file(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(current_cache, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print("[GeminiAPI] Error saving cache:", str(e))

def get_translation(text_to_translate):
    API_KEY = get_api_key()
    if not API_KEY:
        return "Error: No API Key"
    
    if PY2 and isinstance(text_to_translate, binary_type):
        try:
            text_to_translate = text_to_translate.decode('utf-8', 'ignore')
        except:
            text_to_translate = text_to_translate.decode('latin-1', 'ignore')
    
    original_title_key = text_to_translate.split('\n')[0].strip()
    
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + API_KEY
    
    if PY3 and isinstance(API_KEY, binary_type):
        API_KEY = API_KEY.decode('utf-8')
    
    safe_text = text_to_translate.replace('"', ' ').strip()

    prompt = """
    Task: Translate TV event info.
    1. Title: Translate the title to Arabic AND English.
    2. Format Title line exactly like this: 'Arabic Title / English Title'
    3. Description: Translate full description to Arabic.
    4. Output format strictly: Title ||| Description
    
    Input text: {0}
    """.format(safe_text)
    
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    json_file = "/tmp/gemini_manual_req.json"
    
    try:
        with open_file(json_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        
        cmd = 'curl -s -k --max-time 15 -H "Content-Type: application/json" -d @{0} "{1}"'.format(json_file, url)
        stream = os.popen(cmd)
        output = stream.read()
        
        if os.path.exists(json_file):
            os.remove(json_file)
        
        if PY2 and isinstance(output, binary_type):
            try:
                output = output.decode('utf-8', 'ignore')
            except:
                output = output.decode('latin-1', 'ignore')
        
        if '"text":' in output:
            response = json.loads(output)
            raw_text = response['candidates'][0]['content']['parts'][0]['text'].strip()
            
            final_title = ""
            final_desc = ""

            if "|||" in raw_text:
                parts = raw_text.split("|||")
                final_title = parts[0].strip()
                final_desc = parts[1].strip()
            else:
                final_title = raw_text
                final_desc = raw_text
            
            save_to_cache(original_title_key, final_title, final_desc)
            
            if PY2:
                if isinstance(final_title, text_type):
                    final_title = final_title.encode('utf-8', 'ignore')
                if isinstance(final_desc, text_type):
                    final_desc = final_desc.encode('utf-8', 'ignore')
            
            return "{0}\n\n{1}".format(final_title, final_desc)
        else:
            return "Error: API Limit or No Response"

    except Exception as e:
        error_msg = "Error: " + str(e)
        if PY2 and isinstance(error_msg, text_type):
            error_msg = error_msg.encode('utf-8', 'ignore')
        return error_msg


if __name__ == "__main__":
    test_text = "Breaking News\nImportant announcement from the government"
    result = get_translation(test_text)
    print("Test result:", result)
