from __future__ import print_function, absolute_import
import sys

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

if PY2:
    text_type = unicode
    binary_type = str
else:
    text_type = str
    binary_type = bytes

try:
    from Plugins.Plugin import PluginDescriptor
    from Screens.Screen import Screen
    from Components.Label import Label
    from Components.ActionMap import ActionMap
    from enigma import eServiceCenter
    ENIGMA_AVAILABLE = True
except ImportError:
    ENIGMA_AVAILABLE = False

try:
    from twisted.internet import threads
    TWISTED_AVAILABLE = True
except ImportError:
    TWISTED_AVAILABLE = False

try:
    from .gemini_api import get_translation
    GEMINI_AVAILABLE = True
except (ImportError, ValueError):
    try:
        from gemini_api import get_translation
        GEMINI_AVAILABLE = True
    except ImportError:
        GEMINI_AVAILABLE = False


class GeminiScreen(Screen if ENIGMA_AVAILABLE else object):
    skin = """
    <screen name="GeminiScreen" position="center,center" size="1200,650" title="Gemini AI Translate" flags="wfNoBorder" backgroundColor="#000000">
        <eLabel position="0,0" size="1200,2" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="0,648" size="1200,2" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="0,0" size="2,650" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="1198,0" size="2,650" backgroundColor="#ffd700" zPosition="2" />
        
        <widget name="title" position="30,20" size="1140,60" font="Regular;38" foregroundColor="#ffd700" backgroundColor="#000000" halign="center" valign="center" transparent="1" />
        <eLabel position="30,90" size="1140,1" backgroundColor="#555555" />
        
        <widget name="translated_text" position="30,110" size="1140,480" font="Regular;34" foregroundColor="#ffffff" backgroundColor="#000000" valign="top" halign="right" transparent="1" />
        <eLabel text="Press OK or EXIT to close" position="0,600" size="1200,50" font="Regular;24" foregroundColor="#777777" backgroundColor="#000000" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session):
        if ENIGMA_AVAILABLE:
            Screen.__init__(self, session)
        else:
            self.session = session
            self.onLayoutFinish = []
        
        self["title"] = Label("Gemini AI")
        self["translated_text"] = Label("Collecting data and translating...")
        
        if ENIGMA_AVAILABLE:
            self["actions"] = ActionMap(["SetupActions"], {
                "cancel": self.close,
                "ok": self.close,
                "info": self.close
            }, -1)
        
        if hasattr(self, 'onLayoutFinish'):
            self.onLayoutFinish.append(self.prepare_translation)

    def prepare_translation(self):
        if not ENIGMA_AVAILABLE:
            self["translated_text"].setText("Enigma2 environment not available")
            return
        
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            
            self.event_now = info and info.getEvent(0)
            self.event_next = info and info.getEvent(1)
            
            if self.event_now:
                self.process_event(self.event_now, is_current=True)
            else:
                self["title"].setText("No Information")
                self["translated_text"].setText("No EPG available for this channel.")
        except Exception as e:
            self["title"].setText("Error")
            self["translated_text"].setText("Failed to get service info: " + str(e))

    def process_event(self, event, is_current=True):
        try:
            event_name = event.getEventName()
            short_desc = event.getShortDescription() or ""
            ext_desc = event.getExtendedDescription() or ""
            
            if PY2 and isinstance(event_name, binary_type):
                try:
                    event_name = event_name.decode('utf-8', 'ignore')
                except:
                    event_name = event_name.decode('latin-1', 'ignore')
            
            full_desc = short_desc + "\n" + ext_desc
            full_text_to_send = event_name + "\n" + full_desc
            
            if is_current:
                self["title"].setText(event_name)
                self["translated_text"].setText("Connecting to Gemini (Current Event)...")
            
            if TWISTED_AVAILABLE:
                d = threads.deferToThread(self.run_gemini_background, full_text_to_send, event_name)
                
                if is_current:
                    d.addCallback(self.show_result_now).addErrback(self.show_error)
                else:
                    d.addCallback(self.finished_next).addErrback(self.log_error)
            else:
                result = self.run_gemini_background(full_text_to_send, event_name)
                if is_current:
                    self.show_result_now(result)
                else:
                    self.finished_next(result)
        except Exception as e:
            self["translated_text"].setText("Error processing event: " + str(e))

    def show_result_now(self, result):
        if isinstance(result, text_type) and PY2:
            result = result.encode('utf-8', 'ignore')
        self["translated_text"].setText(result)
        if hasattr(self, 'event_next') and self.event_next:
            self.process_event(self.event_next, is_current=False)

    def finished_next(self, result):
        pass

    def log_error(self, error):
        error_msg = str(error)
        if PY2:
            error_msg = error_msg.encode('utf-8', 'ignore')
        print("[GeminiTranslate] Error translating next event: ", error_msg)

    def run_gemini_background(self, text, original_title):
        try:
            if not GEMINI_AVAILABLE:
                return "Error: gemini_api not available"
            
            if PY2 and isinstance(text, binary_type):
                try:
                    text = text.decode('utf-8', 'ignore')
                except:
                    text = text.decode('latin-1', 'ignore')
            
            result = get_translation(text)
            
            if PY2 and isinstance(result, text_type):
                result = result.encode('utf-8', 'ignore')
            
            return result
        except Exception as e:
            error_msg = "Error: " + str(e)
            if PY2 and isinstance(error_msg, text_type):
                error_msg = error_msg.encode('utf-8', 'ignore')
            return error_msg

    def show_error(self, error):
        error_msg = str(error)
        if PY2:
            error_msg = error_msg.encode('utf-8', 'ignore')
        self["translated_text"].setText("Error: " + error_msg)

    def close(self):
        if ENIGMA_AVAILABLE:
            Screen.close(self)


def main(session, **kwargs):
    if not ENIGMA_AVAILABLE:
        print("Enigma2 libraries not available. Running in test mode.")
        screen = GeminiScreen(session)
        screen.prepare_translation()
        return screen
    return session.open(GeminiScreen)


def Plugins(**kwargs):
    if not ENIGMA_AVAILABLE:
        print("Enigma2 PluginDescriptor not available")
        return []
    
    return [PluginDescriptor(
        name="Gemini AI Translate", 
        description="Fast AI Translation", 
        where=PluginDescriptor.WHERE_PLUGINMENU, 
        fnc=main,
        icon="icon.png"
    )]


if __name__ == "__main__":
    class DummySession:
        class Nav:
            def getCurrentService(self):
                class DummyService:
                    class Info:
                        def getEvent(self, num):
                            class DummyEvent:
                                def getEventName(self):
                                    return "Test Event"
                                def getShortDescription(self):
                                    return "Short description"
                                def getExtendedDescription(self):
                                    return "Extended description"
                            return DummyEvent() if num == 0 else None
                    info = Info()
                return DummyService()
        nav = Nav()
    
    screen = GeminiScreen(DummySession())
    screen.prepare_translation()
    print("Test mode running. Translated text would be displayed here.")