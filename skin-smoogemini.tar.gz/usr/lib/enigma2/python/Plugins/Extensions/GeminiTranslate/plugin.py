from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from enigma import eServiceCenter
from twisted.internet import threads

class GeminiScreen(Screen):
    skin = """
    <screen name="GeminiScreen" position="center,center" size="1200,650" title="Gemini AI Translate" flags="wfNoBorder" backgroundColor="#000000">
        <eLabel position="0,0" size="1200,2" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="0,648" size="1200,2" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="0,0" size="2,650" backgroundColor="#ffd700" zPosition="2" />
        <eLabel position="1198,0" size="2,650" backgroundColor="#ffd700" zPosition="2" />
        
        <widget name="title" position="30,20" size="1140,60" font="Regular;38" foregroundColor="#ffd700" backgroundColor="#000000" halign="center" valign="center" transparent="1" />
        <eLabel position="30,90" size="1140,1" backgroundColor="#555555" />
        
        <widget name="translated_text" position="30,110" size="1140,480" font="Regular;34" foregroundColor="#ffffff" backgroundColor="#000000" valign="top" halign="right" transparent="1" />
        <eLabel text="Press OK or EXIT to close" position="0,600" size="1200,50" font="Regular;24" foregroundColor="#777777" backgroundColor="#000000" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label("Gemini AI")
        self["translated_text"] = Label("Collecting data and translating...")
        
        self["actions"] = ActionMap(["SetupActions"], {
            "cancel": self.close,
            "ok": self.close,
            "info": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.prepare_translation)

    def prepare_translation(self):
        service = self.session.nav.getCurrentService()
        info = service and service.info()
        
        self.event_now = info and info.getEvent(0)
        self.event_next = info and info.getEvent(1)
        
        if self.event_now:
            self.process_event(self.event_now, is_current=True)
        else:
            self["title"].setText("No Information")
            self["translated_text"].setText("No EPG available for this channel.")

    def process_event(self, event, is_current=True):
        event_name = event.getEventName()
        short_desc = event.getShortDescription() or ""
        ext_desc = event.getExtendedDescription() or ""
        
        full_desc = short_desc + "\n" + ext_desc
        full_text_to_send = event_name + "\n" + full_desc
        
        if is_current:
            self["title"].setText(event_name)
            self["translated_text"].setText("Connecting to Gemini (Current Event)...")
        
        d = threads.deferToThread(self.run_gemini_background, full_text_to_send, event_name)
        
        if is_current:
            d.addCallback(self.show_result_now).addErrback(self.show_error)
        else:
            d.addCallback(self.finished_next).addErrback(self.log_error)

    def show_result_now(self, result):
        self["translated_text"].setText(result)
        if self.event_next:
            self.process_event(self.event_next, is_current=False)

    def finished_next(self, result):
        pass

    def log_error(self, error):
        print("[GeminiTranslate] Error translating next event: ", error)

    def run_gemini_background(self, text, original_title):
        try:
            from .gemini_api import get_translation
            return get_translation(text) 
        except ImportError:
            return "Error: gemini_api.py not found"
        except Exception as e:
            return "Error: " + str(e)

    def show_error(self, error):
        self["translated_text"].setText("Error: " + str(error))

def main(session, **kwargs):
    session.open(GeminiScreen)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Gemini AI Translate", 
        description="Fast AI Translation", 
        where=PluginDescriptor.WHERE_PLUGINMENU, 
        fnc=main,
        icon="icon.png"
    )]
