# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eEPGCache
import os
import json

class GeminiEvent(Converter, object):
    NAME = 0
    DESCRIPTION = 1

    def __init__(self, type):
        Converter.__init__(self, type)
        if type == "Name":
            self.type = self.NAME
        else:
            self.type = self.DESCRIPTION

    @cached
    def getText(self):
        event = self.source.event
        if event is None:
            return ""
            
        # الحصول على الاسم الأصلي
        original_name = event.getEventName()
        if not original_name:
            return ""

        # تنظيف الاسم من المسافات الزائدة لضمان التطابق
        search_name = original_name.strip()

        cache_path = "/media/hdd/gemini_cache.json"
        if not os.path.exists(cache_path):
            cache_path = "/tmp/gemini_cache.json"

        if os.path.exists(cache_path):
            try:
                # فتح الملف بترميز utf-8 لضمان قراءة العربية
                with open(cache_path, "r") as f:
                    data = json.load(f)
                
                # محاولة البحث بالاسم كما هو، أو بالاسم المنظف
                item = data.get(original_name) or data.get(search_name)

                if item:
                    if self.type == self.NAME:
                        # جلب العنوان، إذا كان فارغاً نعود للاسم الأصلي
                        title = item.get("title", "")
                        return str(title) if title else original_name
                    
                    elif self.type == self.DESCRIPTION:
                        # جلب الوصف
                        desc = item.get("desc", "")
                        return str(desc)
            except Exception as e:
                # طباعة الخطأ في التيرمينال للمساعدة في التتبع
                print("[GeminiEvent] Error reading JSON:", e)
                pass
        
        # في حال عدم وجود ملف أو ترجمة، نعرض البيانات الأصلية
        if self.type == self.NAME:
            return original_name
        else:
            return event.getExtendedDescription() or event.getShortDescription() or ""

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)