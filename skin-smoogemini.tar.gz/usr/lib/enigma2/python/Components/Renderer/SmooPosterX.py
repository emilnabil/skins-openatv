#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import print_function
from Components.Renderer.Renderer import Renderer
from Components.Renderer.SmooPosterXDownloadThread import SmooPosterXDownloadThread
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG, eEPGCache, eTimer
import NavigationInstance
import os
import sys
import time
import traceback
import datetime
from .SmooConverlibr import convtext

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import queue
else:
    import Queue as queue

epgcache = eEPGCache.getInstance()
if PY3:
    pdb = queue.LifoQueue()
else:
    pdb = queue.LifoQueue()

def isMountedInRW(mount_point):
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) > 1 and parts[1] == mount_point:
                    return True
    except:
        pass
    return False

# --- تعديل المسار ليكون مجلد XtraEvent ---
path_folder = "/tmp/poster"
if os.path.exists("/media/hdd"):
    if isMountedInRW("/media/hdd"):
        path_folder = "/media/hdd/xtraEvent/poster"
elif os.path.exists("/media/usb"):
    if isMountedInRW("/media/usb"):
        path_folder = "/media/usb/xtraEvent/poster"
elif os.path.exists("/media/mmc"):
    if isMountedInRW("/media/mmc"):
        path_folder = "/media/mmc/xtraEvent/poster"

if not os.path.exists(path_folder):
    try:
        os.makedirs(path_folder)
    except:
        pass
# ------------------------------------------

apdb = dict()

try:
    lng = config.osd.language.value
    lng = lng[:-3]
except:
    lng = 'en'

# دالة للتحقق من الإنترنت
def intCheck():
    try:
        if PY3:
            from urllib.request import urlopen
        else:
            from urllib2 import urlopen
        response = urlopen("http://google.com", None, 5)
        response.close()
    except:
        return False
    return True

# --- كلاس التحميل (Thread) ---
# هذا الكلاس هو المسؤول عن التحميل من النت إذا لم توجد الصورة
class PosterDB(SmooPosterXDownloadThread):
    def __init__(self):
        SmooPosterXDownloadThread.__init__(self)
        self.pstcanal = None

    def run(self):
        while True:
            canal = pdb.get()
            self.pstcanal = convtext(canal[5])

            if self.pstcanal is not None:
                # هنا نوجه التحميل لنفس مجلد XtraEvent
                dwn_poster = os.path.join(path_folder, self.pstcanal + ".jpg")
            else:
                pdb.task_done()
                continue

            if os.path.exists(dwn_poster):
                os.utime(dwn_poster, (time.time(), time.time()))
            
            # إذا الصورة غير موجودة، ابدأ البحث في المصادر
            if not os.path.exists(dwn_poster):
                val, log = self.search_tmdb(dwn_poster, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_poster):
                val, log = self.search_tvdb(dwn_poster, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_poster):
                val, log = self.search_fanart(dwn_poster, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_poster):
                val, log = self.search_imdb(dwn_poster, self.pstcanal, canal[4], canal[3])
            
            pdb.task_done()

# تشغيل ثريد التحميل في الخلفية
threadDB = PosterDB()
threadDB.start()


# --- الريندر الرئيسي للسكين ---
class SmooPosterX(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        self.adsl = intCheck()
        self.nxts = 0
        self.path = path_folder # استخدام مسار XtraEvent
        self.canal = [None, None, None, None, None, None]
        self.oldCanal = None
        self.pstcanal = None
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.showPoster)
        except:
            self.timer.callback.append(self.showPoster)

    def applySkin(self, desktop, parent):
        attribs = []
        for (attrib, value,) in self.skinAttributes:
            if attrib == "nexts":
                self.nxts = int(value)
            # نتجاهل أي مسار قادم من السكين ونفرض مسارنا
            if attrib == "path":
                continue
            attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.instance:
            return
        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
            return

        servicetype = None
        try:
            service = None
            source_type = type(self.source)
            if source_type is ServiceEvent:
                service = self.source.getCurrentService()
                servicetype = "ServiceEvent"
            elif source_type is CurrentService:
                service = self.source.getCurrentServiceRef()
                servicetype = "CurrentService"
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                servicetype = "EventInfo"
            elif source_type is Event:
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    self.canal[0] = None
                    self.canal[1] = self.source.event.getBeginTime()
                    self.canal[2] = self.source.event.getEventName()
                    self.canal[3] = self.source.event.getExtendedDescription()
                    self.canal[4] = self.source.event.getShortDescription()
                    self.canal[5] = self.canal[2]
                servicetype = "Event"
            
            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(['IBDCTESX', (service_str, 0, -1, -1)])
                self.canal[0] = ServiceReference(service).getServiceName()
                self.canal[1] = events[self.nxts][1]
                self.canal[2] = events[self.nxts][4]
                self.canal[3] = events[self.nxts][5]
                self.canal[4] = events[self.nxts][6]
                self.canal[5] = self.canal[2]

        except Exception as e:
            if self.instance:
                self.instance.hide()
            return

        try:
            curCanal = "{}-{}".format(self.canal[1], self.canal[2])
            if curCanal == self.oldCanal:
                return

            self.oldCanal = curCanal
            self.pstcanal = convtext(self.canal[5])
            
            if self.pstcanal:
                pstrNm = os.path.join(self.path, self.pstcanal + ".jpg")
                if os.path.exists(pstrNm):
                    # وجدنا الصورة في XtraEvent
                    self.instance.setPixmap(loadJPG(pstrNm))
                    self.instance.setScale(1)
                    self.instance.show()
                else:
                    # لم نجد الصورة، شغل التحميل
                    if self.adsl:
                        canal = self.canal[:]
                        pdb.put(canal)
                        # انتظر قليلاً حتى يحملها الثريد
                        self.timer.start(1000, True)
                    else:
                        self.instance.hide()
            else:
                self.instance.hide()

        except Exception as e:
            if self.instance:
                self.instance.hide()

    def showPoster(self):
        if self.instance and self.pstcanal:
            pstrNm = os.path.join(self.path, self.pstcanal + ".jpg")
            if os.path.exists(pstrNm):
                self.instance.setPixmap(loadJPG(pstrNm))
                self.instance.setScale(1)
                self.instance.show()