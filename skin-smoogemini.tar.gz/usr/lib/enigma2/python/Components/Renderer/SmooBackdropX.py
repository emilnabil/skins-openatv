#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import print_function
from Components.Renderer.Renderer import Renderer
from Components.Renderer.SmooBackdropXDownloadThread import SmooBackdropXDownloadThread
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG, eEPGCache, eTimer
import NavigationInstance
import os
import sys
import time
import traceback
import datetime
from .SmooConverlibr import convtext

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import queue
    from _thread import start_new_thread
    from urllib.error import HTTPError, URLError
    from urllib.request import urlopen
else:
    import Queue as queue
    from thread import start_new_thread
    from urllib2 import HTTPError, URLError
    from urllib2 import urlopen


epgcache = eEPGCache.getInstance()
if PY3:
    pdb = queue.LifoQueue()
else:
    pdb = queue.LifoQueue()


def isMountedInRW(mount_point):
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) > 1 and parts[1] == mount_point:
                    return True
    except:
        pass
    return False


cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
noposter = "/usr/share/enigma2/%s/main/noposter.jpg" % cur_skin

# --- تعديل المسار ليتوافق مع XtraEvent Backdrop ---
path_folder = "/tmp/backdrop"
if os.path.exists("/media/hdd"):
    if isMountedInRW("/media/hdd"):
        path_folder = "/media/hdd/xtraEvent/backdrop"
elif os.path.exists("/media/usb"):
    if isMountedInRW("/media/usb"):
        path_folder = "/media/usb/xtraEvent/backdrop"
elif os.path.exists("/media/mmc"):
    if isMountedInRW("/media/mmc"):
        path_folder = "/media/mmc/xtraEvent/backdrop"

if not os.path.exists(path_folder):
    try:
        os.makedirs(path_folder)
    except:
        pass
# --------------------------------------------------

epgcache = eEPGCache.getInstance()
apdb = dict()


try:
    lng = config.osd.language.value
    lng = lng[:-3]
except:
    lng = 'en'
    pass

def SearchBouquetTerrestrial():
    import glob
    import codecs
    file = '/etc/enigma2/userbouquet.favourites.tv'
    for file in sorted(glob.glob('/etc/enigma2/*.tv')):
        with codecs.open(file, "r", encoding="utf-8") as f:
            file = f.read()
            x = file.strip().lower()
            if x.find('eeee') != -1:
                if x.find('82000') == -1 and x.find('c0000') == -1:
                    return file
                    break

autobouquet_file = None

def process_autobouquet():
    global autobouquet_file
    autobouquet_file = SearchBouquetTerrestrial() or '/etc/enigma2/userbouquet.favourites.tv'
    autobouquet_count = 70
    apdb = {}

    if not os.path.exists(autobouquet_file):
        return {}

    try:
        with open(autobouquet_file, 'r') as f:
            lines = f.readlines()
    except:
        return {}

    autobouquet_count = min(autobouquet_count, len(lines))

    for i, line in enumerate(lines[:autobouquet_count]):
        if line.startswith('#SERVICE'):
            parts = line[9:].strip().split(':')
            if len(parts) == 11 and ':'.join(parts[3:7]) != '0:0:0:0':
                apdb[i] = ':'.join(parts)

    return apdb

apdb = process_autobouquet()

def intCheck():
    try:
        if PY3:
            from urllib.request import urlopen
            from urllib.error import URLError, HTTPError
        else:
            from urllib2 import urlopen, URLError, HTTPError
        response = urlopen("http://google.com", None, 5)
        response.close()
    except:
        return False
    return True


omdb_api = "6a4c9432"

class BackdropDB(SmooBackdropXDownloadThread):
    def __init__(self):
        SmooBackdropXDownloadThread.__init__(self)
        self.logdbg = None
        self.pstcanal = None

    def run(self):
        while True:
            canal = pdb.get()
            self.pstcanal = convtext(canal[5])

            if self.pstcanal is not None:
                dwn_backdrop = os.path.join(path_folder, self.pstcanal + ".jpg")
            else:
                pdb.task_done() 
                continue

            if os.path.exists(dwn_backdrop):
                os.utime(dwn_backdrop, (time.time(), time.time()))

            if not os.path.exists(dwn_backdrop):
                val, log = self.search_tmdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_backdrop):
                val, log = self.search_tvdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_backdrop):
                val, log = self.search_fanart(dwn_backdrop, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_backdrop):
                val, log = self.search_imdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
            elif not os.path.exists(dwn_backdrop):
                val, log = self.search_google(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])

            pdb.task_done()

    def logDB(self, logmsg):
        try:
            with open("/tmp/BackdropDB.log", "a") as w:
                w.write("%s\n" % logmsg)
        except:
            pass


threadDB = BackdropDB()
threadDB.start()


class BackdropAutoDB(SmooBackdropXDownloadThread):
    def __init__(self):
        SmooBackdropXDownloadThread.__init__(self)
        self.logdbg = None
        self.pstcanal = None

    def run(self):
        while True:
            time.sleep(7200)
            self.pstcanal = None
            for service in apdb.values():
                try:
                    events = epgcache.lookupEvent(['IBDCTESX', (service, 0, -1, 1440)])
                    newfd = 0
                    newcn = None
                    for evt in events:
                        canal = [None] * 6
                        if PY3:
                            canal[0] = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                        else:
                            canal[0] = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '').encode('utf-8')
                        if evt[1] is None or evt[4] is None or evt[5] is None or evt[6] is None:
                            pass
                        else:
                            canal[1:6] = [evt[1], evt[4], evt[5], evt[6], evt[4]]
                            self.pstcanal = convtext(canal[5]) if canal[5] else None

                            if self.pstcanal is not None:
                                dwn_backdrop = os.path.join(path_folder, self.pstcanal + ".jpg")
                            else:
                                continue

                            if os.path.exists(dwn_backdrop):
                                os.utime(dwn_backdrop, (time.time(), time.time()))

                            if not os.path.exists(dwn_backdrop):
                                val, log = self.search_tmdb(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])
                            elif not os.path.exists(dwn_backdrop):
                                val, log = self.search_tvdb(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])
                            elif not os.path.exists(dwn_backdrop):
                                val, log = self.search_fanart(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])
                            elif not os.path.exists(dwn_backdrop):
                                val, log = self.search_imdb(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])
                            elif not os.path.exists(dwn_backdrop):
                                val, log = self.search_google(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])

                except:
                    pass

threadAutoDB = BackdropAutoDB()
threadAutoDB.start()


class SmooBackdropX(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        self.adsl = intCheck()
        self.nxts = 0
        self.path = path_folder
        self.canal = [None, None, None, None, None, None]
        self.oldCanal = None
        self.logdbg = None
        self.pstcanal = None
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.showBackdrop)
        except:
            self.timer.callback.append(self.showBackdrop)

    def applySkin(self, desktop, parent):
        attribs = []
        for (attrib, value,) in self.skinAttributes:
            if attrib == "nexts":
                self.nxts = int(value)
            # تجاهل مسار السكين
            if attrib == "path":
                continue
            attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.instance:
            return
        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
            return

        servicetype = None
        try:
            service = None
            source_type = type(self.source)
            if source_type is ServiceEvent:
                service = self.source.getCurrentService()
                servicetype = "ServiceEvent"
            elif source_type is CurrentService:
                service = self.source.getCurrentServiceRef()
                servicetype = "CurrentService"
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                servicetype = "EventInfo"
            elif source_type is Event:
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    self.canal[0] = None
                    self.canal[1] = self.source.event.getBeginTime()
                    event_name = self.source.event.getEventName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                    if not PY3:
                        event_name = event_name.encode('utf-8')
                    self.canal[2] = event_name
                    self.canal[3] = self.source.event.getExtendedDescription()
                    self.canal[4] = self.source.event.getShortDescription()
                    self.canal[5] = event_name
                servicetype = "Event"
            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(['IBDCTESX', (service_str, 0, -1, -1)])
                service_name = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                if not PY3:
                    service_name = service_name.encode('utf-8')
                self.canal[0] = service_name
                self.canal[1] = events[self.nxts][1]
                self.canal[2] = events[self.nxts][4]
                self.canal[3] = events[self.nxts][5]
                self.canal[4] = events[self.nxts][6]
                self.canal[5] = self.canal[2]

                if not autobouquet_file and service_name not in apdb:
                    apdb[service_name] = service_str

        except Exception as e:
            print("Error (service):", str(e))
            if self.instance:
                self.instance.hide()
            return

        try:
            curCanal = "{}-{}".format(self.canal[1], self.canal[2])
            if curCanal == self.oldCanal:
                return

            self.oldCanal = curCanal
            self.pstcanal = convtext(self.canal[5])
            if self.pstcanal is not None:
                self.pstrNm = os.path.join(self.path, str(self.pstcanal) + ".jpg")
                self.pstcanal = self.pstrNm

            if os.path.exists(self.pstcanal):
                self.timer.start(10, True)
            else:
                canal = self.canal[:]
                pdb.put(canal)
                start_new_thread(self.waitBackdrop, ())

        except Exception as e:
            print("Error (eFile):", str(e))
            if self.instance:
                self.instance.hide()
            return

    def generatePosterPath(self):
        if self.canal[5]:
            pstcanal = convtext(self.canal[5])
            return os.path.join(self.path, str(pstcanal) + ".jpg")
        return None

    def showBackdrop(self):
        if self.instance:
            self.instance.hide()
        self.pstrNm = self.generatePosterPath()
        if self.pstrNm and os.path.exists(self.pstrNm):
            self.instance.setPixmap(loadJPG(self.pstrNm))
            self.instance.setScale(1)
            self.instance.show()

    def waitBackdrop(self):
        if self.instance:
            self.instance.hide()

        self.pstrNm = self.generatePosterPath()
        if self.pstrNm:
            loop = 180
            found = False
            while loop > 0:
                if os.path.exists(self.pstrNm):
                    found = True
                    break
                time.sleep(0.5)
                loop -= 1
            if found:
                self.timer.start(10, True)

    def logBackdrop(self, logmsg):
        try:
            with open("/tmp/XDREAMY_Backdrop.log", "a") as w:
                w.write("%s\n" % logmsg)
        except:
            pass