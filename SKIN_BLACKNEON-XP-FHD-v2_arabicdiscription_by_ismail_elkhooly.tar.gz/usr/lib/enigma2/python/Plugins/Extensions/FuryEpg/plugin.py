# -*- coding: utf-8 -*-
# FuryEpg plugin - EPG Google Translate with cache (no translation mode)

from Components.Pixmap import Pixmap
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config,
    ConfigSubsection,
    ConfigYesNo,
    ConfigSelection,
    ConfigText,
    getConfigListEntry,
)
import os
import json
import threading


def get_default_cache_path():
    """Return default cache file path based on available mount points."""
    candidates = [
        "/media/hdd",
        "/media/usb",
        "/media/usb0",
        "/media/usb1",
        "/media/mmc",
        "/media/mmc1",
        "/media/usb2",
        "/media/usb3",
    ]
    for base in candidates:
        if os.path.isdir(base):
            return os.path.join(base, "furyepg_cache.json")
    return "/tmp/furyepg_cache.json"


# ---------- configuration ----------

config.plugins.furyepg = ConfigSubsection()
config.plugins.furyepg.enabled = ConfigYesNo(default=True)
config.plugins.furyepg.language = ConfigSelection(
    default="ar",
    choices=[
        ("ar", "Arabic"),
        ("en", "English"),
        ("fr", "French"),
        ("de", "German"),
        ("it", "Italian"),
        ("es", "Spanish"),
        ("ru", "Russian"),
        ("zh", "Chinese"),
        ("ja", "Japanese"),
    ],
)
# تظهر "no path" حتى يختار المستخدم مسارًا
config.plugins.furyepg.cachepath = ConfigText(
    default="no path", fixed_size=False
)
config.plugins.furyepg.clearcache = ConfigYesNo(default=False)


# ---------- controller ----------

class FuryEpgController(object):
    instance = None

    def __init__(self, session):
        print("[FuryEpg] Controller __init__ called, session=%s" % (session,))
        FuryEpgController.instance = self
        self.session = session
        self.enabled = config.plugins.furyepg.enabled.value

        # Determine cache path: treat "no path" كأنه فارغ
        cfg_raw = (config.plugins.furyepg.cachepath.value or "").strip()
        if cfg_raw.lower() == "no path":
            cfg_path = ""
        else:
            cfg_path = cfg_raw

        if not cfg_path:
            # مسار داخلي افتراضي عندما لا يختار المستخدم مسارًا
            base = "/tmp"
            cfg_path = os.path.join(base, "FuryEpg", "furyepg_cache.json")

        cache_dir = os.path.dirname(cfg_path)
        if cache_dir and not os.path.isdir(cache_dir):
            try:
                os.makedirs(cache_dir)
            except Exception as e:
                print("[FuryEpg] error creating cache dir %s: %s" % (cache_dir, e))

        self.cachepath = cfg_path
        self.cache = {}

        # cache tuning
        self._cache_dirty = 0
        self._cache_save_interval = 10
        self._cache_max_items = 5000

        self._load_cache()
        self._patch_targets()

    # ---------- cache ----------

    def _load_cache(self):
        path = self.cachepath
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = f.read()
                if data.strip():
                    self.cache = json.loads(data)
                else:
                    self.cache = {}
                self._cache_dirty = 0
                print("[FuryEpg] cache loaded from %s (%d items)" % (path, len(self.cache)))
            else:
                self.cache = {}
                self._cache_dirty = 0
                print("[FuryEpg] no cache file at %s, starting empty" % path)
                self._save_cache(force=True)
        except Exception as e:
            print("[FuryEpg] load_cache error: %s" % e)
            self.cache = {}
            self._cache_dirty = 0

    def _shrink_cache(self, max_items):
        try:
            if max_items <= 0 or len(self.cache) <= max_items:
                return
            items = list(self.cache.items())
            self.cache = dict(items[-max_items:])
            print("[FuryEpg] cache trimmed to %d items" % len(self.cache))
        except Exception as e:
            print("[FuryEpg] cache shrink error: %s" % e)

    def _save_cache(self, force=False):
        if not force and getattr(self, "_cache_dirty", 0) <= 0:
            return
        path = self.cachepath
        try:
            d = os.path.dirname(path)
            if d and not os.path.exists(d):
                os.makedirs(d)
            with open(path, "w") as f:
                json.dump(self.cache, f)
            self._cache_dirty = 0
            print("[FuryEpg] cache saved to %s (%d items)" % (path, len(self.cache)))
        except Exception as e:
            print("[FuryEpg] save_cache error: %s" % e)

    def clear_cache(self):
        self.cache = {}
        self._cache_dirty = 0
        try:
            if os.path.exists(self.cachepath):
                os.remove(self.cachepath)
        except Exception as e:
            print("[FuryEpg] clear_cache error: %s" % e)
        print("[FuryEpg] cache cleared")

    # ---------- translation ----------

    def _get_translator(self):
        try:
            from .google_translate_api import translate_text as gt_translate
        except ImportError as e:
            print("[FuryEpg] cannot import google_translate_api: %s" % e)
            return None

        def _do_translate(text, lang):
            return gt_translate(text, target_lang=lang)

        return _do_translate

    def translate(self, text):
        lang = config.plugins.furyepg.language.value

        if not text:
            return text

        cache_key = "%s|%s" % (lang, text)

        if cache_key in self.cache:
            return self.cache[cache_key]

        if not self.enabled:
            return text

        translator = self._get_translator()
        if translator is None:
            return text

        try:
            translated = translator(text, lang)
            if not isinstance(translated, str) or not translated.strip():
                return text
        except Exception as e:
            print("[FuryEpg] error in translate provider: %s" % e)
            return text

        self.cache[cache_key] = translated

        try:
            max_items = getattr(self, "_cache_max_items", 0) or 0
            if max_items and len(self.cache) > max_items:
                self._shrink_cache(max_items)
        except Exception as e:
            print("[FuryEpg] cache soft-limit error: %s" % e)

        try:
            self._cache_dirty = getattr(self, "_cache_dirty", 0) + 1
        except Exception:
            self._cache_dirty = 1

        interval = getattr(self, "_cache_save_interval", 0) or 0
        if interval and self._cache_dirty >= interval:
            self._save_cache()

        return translated

    def translate_async(self, text):
        if not text or not self.enabled:
            return

        lang = config.plugins.furyepg.language.value
        cache_key = "%s|%s" % (lang, text)
        if cache_key in self.cache:
            return

        def worker():
            try:
                self.translate(text)
            except Exception as e:
                print("[FuryEpg] translate_async worker error: %s" % e)

        t = threading.Thread(target=worker)
        t.setDaemon(True)
        t.start()

    # ---------- monkey patches ----------

    def _patch_targets(self):
        # EventViewBase
        try:
            from Screens.EventView import EventViewBase

            if not hasattr(EventViewBase, "_furyepg_patched"):
                print("[FuryEpg] Patching EventViewBase.setEvent")

                orig_setEvent = EventViewBase.setEvent

                def f_setEvent(this, event=None):
                    orig_setEvent(this, event)
                    try:
                        if event is None:
                            return
                        name = event.getEventName() or ""
                        short = event.getShortDescription() or ""
                        extended = event.getExtendedDescription() or ""
                        description = short
                        if extended:
                            if description:
                                description += "\n\n" + extended
                            else:
                                description = extended

                        name_t = self.translate(name)
                        desc_t = self.translate(description)

                        try:
                            this.setTitle(name_t)
                        except Exception:
                            pass

                        for wname in ("epg_eventname", "event_name", "epg_name", "Service"):
                            try:
                                if wname in this:
                                    this[wname].setText(name_t)
                            except Exception:
                                pass

                        if desc_t:
                            for wname in (
                                "epg_description",
                                "description",
                                "epg_info",
                                "info",
                                "epg_extendeddescription",
                            ):
                                try:
                                    if wname in this:
                                        this[wname].setText(desc_t)
                                        break
                                except Exception:
                                    pass
                    except Exception as e:
                        print("[FuryEpg] patched EventViewBase.setEvent error: %s" % e)

                EventViewBase.setEvent = f_setEvent
                EventViewBase._furyepg_patched = True
        except Exception as e:
            print("[FuryEpg] could not patch EventViewBase: %s" % e)

        # EventView
        try:
            from Screens.EventView import EventView

            if not hasattr(EventView, "_furyepg_patched"):
                print("[FuryEpg] Patching EventView.setEvent (compat)")

                orig_setEvent2 = EventView.setEvent

                def f_setEvent2(this, service, event):
                    orig_setEvent2(this, service, event)
                    try:
                        if event is None:
                            return
                        name = event.getEventName() or ""
                        short = event.getShortDescription() or ""
                        extended = event.getExtendedDescription() or ""
                        description = short
                        if extended:
                            if description:
                                description += "\n\n" + extended
                            else:
                                description = extended

                        name_t = self.translate(name)
                        desc_t = self.translate(description)

                        try:
                            this.setTitle(name_t)
                        except Exception:
                            pass

                        if desc_t:
                            for wname in (
                                "epg_description",
                                "description",
                                "epg_info",
                                "info",
                                "epg_extendeddescription",
                            ):
                                try:
                                    if wname in this:
                                        this[wname].setText(desc_t)
                                        break
                                except Exception:
                                    pass
                    except Exception as e:
                        print("[FuryEpg] patched EventView.setEvent error: %s" % e)

                EventView.setEvent = f_setEvent2
                EventView._furyepg_patched = True
        except Exception as e:
            print("[FuryEpg] could not patch EventView: %s" % e)

        # EPGSelection
        try:
            from Screens.EpgSelection import EPGSelection

            if not hasattr(EPGSelection, "_furyepg_patched"):
                print("[FuryEpg] Patching EPGSelection.onSelectionChanged")

            orig_onSel = EPGSelection.onSelectionChanged

            def f_onSelectionChanged(this):
                orig_onSel(this)
                try:
                    if "list" not in this:
                        return
                    cur = this["list"].getCurrent()
                    if not cur:
                        return
                    event = cur[0]
                    if not event:
                        return
                    name = event.getEventName() or ""
                    short = event.getShortDescription() or ""
                    extended = event.getExtendedDescription() or ""
                    description = short
                    if extended:
                        if description:
                            description += "\n\n" + extended
                        else:
                            description = extended

                    name_t = self.translate(name)
                    desc_t = self.translate(description)

                    for wname in ("epg_eventname", "event_name", "Service"):
                        try:
                            if wname in this:
                                this[wname].setText(name_t)
                        except Exception:
                            pass

                    if desc_t:
                        for wname in (
                            "epg_description",
                            "key_info",
                            "epg_info",
                            "description",
                        ):
                            try:
                                if wname in this:
                                    this[wname].setText(desc_t)
                                    break
                            except Exception:
                                pass
                except Exception as e:
                    print("[FuryEpg] patched EPGSelection.onSelectionChanged error: %s" % e)

            EPGSelection.onSelectionChanged = f_onSelectionChanged
            EPGSelection._furyepg_patched = True
        except Exception as e:
            print("[FuryEpg] could not patch EPGSelection: %s" % e)

        # ChannelSelection
        try:
            from Screens.ChannelSelection import ChannelSelection

            if not hasattr(ChannelSelection, "_furyepg_patched"):
                print("[FuryEpg] Patching ChannelSelection.infoKeyPressed")

            orig_info = ChannelSelection.infoKeyPressed

            def f_infoKeyPressed(this):
                try:
                    orig_info(this)
                except Exception as e:
                    print("[FuryEpg] ChannelSelection.infoKeyPressed error: %s" % e)

            ChannelSelection.infoKeyPressed = f_infoKeyPressed
            ChannelSelection._furyepg_patched = True
        except Exception as e:
            print("[FuryEpg] could not patch ChannelSelection: %s" % e)
            
            # ---------- Info screen (زر أزرق) ----------

class FuryEpgInfoScreen(Screen):
    """
    شاشة معلومات خاصة بالبلجن.
    السكين فقط، وأنت حر تعدّل أو تضيف محتوى داخل __init__ كما تريد.
    """
    skin = (
        '<screen name="FuryEpgInfoScreen" position="center,center" size="700,400" title="FuryEpg Info">'
        '  <widget name="logo" position="20,20" size="150,150" alphatest="on" />'
        '  <widget name="text" position="190,20" size="490,320" font="Regular;20" halign="left" valign="top" />'
        '  <eLabel text="OK / EXIT = Close" position="20,360" size="660,20" font="Regular;18" halign="center" />'
        '</screen>'
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        # Widgets مطابقة للسكين – بدون أي نص أو صورة جاهزة
        self["logo"] = Pixmap()
        self["text"] = Label("")

        # أزرار OK و EXIT للإغلاق
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "ok": self.close,
                "cancel": self.close,
            },
            -1,
        )



# ---------- setup screen ----------

class FuryEpgSetup(Screen, ConfigListScreen):
    skin = (
        '<screen name="FuryEpgSetup" position="center,center" size="800,400" title="FuryEpg Setup">'
        '<widget name="config" position="20,20" size="760,300" scrollbarMode="showOnDemand" />'
        '<widget name="info" position="20,330" size="760,40" font="Regular;20" halign="center" valign="center" />'
        '<eLabel text="OK = Choose option   |   Green = Save   |   Yellow = Clear cache   |   Blue = Info   |   Red/EXIT = Cancel" '
        'position="20,370" size="760,20" font="Regular;18" halign="center" />'
        '</screen>'
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["info"] = Label("FuryEpg - translation control")

        lst = []
        lst.append(getConfigListEntry("Enable translation", config.plugins.furyepg.enabled))
        lst.append(getConfigListEntry("Translation language", config.plugins.furyepg.language))
        lst.append(getConfigListEntry("Cache file path", config.plugins.furyepg.cachepath))
        lst.append(getConfigListEntry("Clear cache now", config.plugins.furyepg.clearcache))

        ConfigListScreen.__init__(self, lst, session=session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok": self.keyOk,
                "green": self.keySave,
                "yellow": self.keyClear,
                "blue": self.keyInfo,
                "red": self.keyCancel,
                "cancel": self.keyCancel,
            },
            -1,
        )

    def keyOk(self):
        """
        OK:
        - Translation language → ChoiceBox.
        - Yes/No أو Selection → ChoiceBox.
        - Cache file path → ChoiceBox لاختيار قرص (HDD/USB/...) بدون LocationBox أو كيبورد.
        """
        cur = self["config"].getCurrent()
        if cur is None:
            return
        cfg = cur[1]

        # ---- اللغات ----
        if cfg == config.plugins.furyepg.language:
            label_to_value = {}
            display_list = []
            for (val, text) in cfg.choices:
                display_list.append((text, text))
                label_to_value[text] = val

            def _cb_lang(res):
                if res is None:
                    return
                label = res[0]
                value = label_to_value.get(label)
                if value is None:
                    return
                try:
                    cfg.value = value
                    self["config"].invalidate()
                except Exception as e:
                    print("[FuryEpg] error setting language:", e)

            self.session.openWithCallback(
                _cb_lang,
                ChoiceBox,
                title="Select language",
                list=display_list,
            )
            return

        from Components.config import ConfigSelection, ConfigYesNo, ConfigText

        # ---- Selection / YesNo ----
        if isinstance(cfg, (ConfigSelection, ConfigYesNo)):
            display_list = []

            if isinstance(cfg, ConfigYesNo):
                display_list = [("Yes", True), ("No", False)]
            else:
                for (val, text) in cfg.choices:
                    display_list.append((text, val))

            def _cb_sel(res):
                if res is None:
                    return
                value = res[1]
                try:
                    cfg.value = value
                    self["config"].invalidate()
                except Exception as e:
                    print("[FuryEpg] error setting selection:", e)

            self.session.openWithCallback(
                _cb_sel,
                ChoiceBox,
                title="Select value",
                list=display_list,
            )
            return

        # ---- Cache file path → ChoiceBox لاختيار قرص ثم إنشاء FuryEpg تحته ----
        if cfg == config.plugins.furyepg.cachepath:
            choices = []

            mounts = [
                ("/media/hdd", "HDD (/media/hdd)"),
                ("/media/usb", "USB (/media/usb)"),
                ("/media/usb0", "USB0 (/media/usb0)"),
                ("/media/usb1", "USB1 (/media/usb1)"),
                ("/media/mmc", "MMC (/media/mmc)"),
                ("/media/mmc1", "MMC1 (/media/mmc1)"),
            ]
            for path, label in mounts:
                if os.path.isdir(path):
                    choices.append((label, path))

            # في حالة عدم وجود أي قرص، نضيف /tmp
            choices.append(("Internal /tmp (/tmp)", "/tmp"))

            def _cb_cache_dir(res):
                if res is None:
                    return
                base_dir = res[1] or "/tmp"
                try:
                    base_dir = ("%s" % base_dir).strip().rstrip("/") or "/tmp"
                    plugin_dir = os.path.join(base_dir, "FuryEpg")
                    file_path = os.path.join(plugin_dir, "furyepg_cache.json")

                    try:
                        if not os.path.isdir(plugin_dir):
                            os.makedirs(plugin_dir)
                    except Exception as ee:
                        print("[FuryEpg] warning: could not create cache dir: %s" % ee)

                    cfg.value = file_path
                    self["config"].invalidate()
                    print("[FuryEpg] new cache path selected (choicebox):", file_path)

                    ctrl = FuryEpgController.instance
                    if ctrl is not None:
                        try:
                            ctrl.cachepath = file_path
                            ctrl._load_cache()
                        except Exception as ee:
                            print("[FuryEpg] error reloading cache after path change: %s" % ee)

                except Exception as e:
                    print("[FuryEpg] error in cache dir ChoiceBox callback: %s" % e)

            self.session.openWithCallback(
                _cb_cache_dir,
                ChoiceBox,
                title="Select cache directory",
                list=choices,
            )
            return

        # ---- منع ظهور الكيبورد لأي ConfigText ----
        if isinstance(cfg, ConfigText):
            # لا نفعل شيئًا، ولا نستدعي ConfigListScreen.keyOK
            return

        # ---- default لأي نوع آخر ----
        try:
            ConfigListScreen.keyOK(self)
        except Exception as e:
            print("[FuryEpg] keyOk default handler error: %s" % e)

    def keySave(self):
        clear_now = config.plugins.furyepg.clearcache.value

        for x in self["config"].list:
            x[1].save()
        config.plugins.furyepg.save()

        ctrl = FuryEpgController.instance
        if ctrl is not None:
            ctrl.enabled = config.plugins.furyepg.enabled.value

            cfg_raw = (config.plugins.furyepg.cachepath.value or "").strip()
            if cfg_raw.lower() == "no path":
                new_path = os.path.join("/tmp", "FuryEpg", "furyepg_cache.json")
            else:
                new_path = cfg_raw or os.path.join("/tmp", "FuryEpg", "furyepg_cache.json")

            ctrl.cachepath = new_path

            if clear_now:
                try:
                    ctrl.clear_cache()
                    print("[FuryEpg] cache cleared from setup")
                except Exception as e:
                    print("[FuryEpg] error clearing cache from setup: %s" % e)
            else:
                ctrl._load_cache()

        if clear_now:
            config.plugins.furyepg.clearcache.value = False
            config.plugins.furyepg.clearcache.save()

        msg = "Settings saved."
        if clear_now:
            msg += "\nCache has been cleared."

        def _after_msg(result=None):
            self.close()

        self.session.openWithCallback(
            _after_msg,
            MessageBox,
            msg,
            MessageBox.TYPE_INFO,
            timeout=3,
        )

    def keyClear(self):
        ctrl = FuryEpgController.instance
        if ctrl is None:
            self.session.open(
                MessageBox,
                "Controller not ready, cannot clear cache.",
                MessageBox.TYPE_ERROR,
                timeout=3,
            )
            return

        try:
            ctrl.clear_cache()
            config.plugins.furyepg.clearcache.value = False
            config.plugins.furyepg.clearcache.save()
            self.session.open(
                MessageBox,
                "Cache has been cleared.",
                MessageBox.TYPE_INFO,
                timeout=3,
            )
        except Exception as e:
            print("[FuryEpg] keyClear error: %s" % e)
            self.session.open(
                MessageBox,
                "Error clearing cache:\n%s" % e,
                MessageBox.TYPE_ERROR,
                timeout=4,
            )

    def keyInfo(self):
        """
        الزر الأزرق: يفتح شاشة Info (FuryEpgInfoScreen).
        """
        try:
            self.session.open(FuryEpgInfoScreen)
        except Exception as e:
            print("[FuryEpg] keyInfo error: %s" % e)
            self.session.open(
                MessageBox,
                "Error opening info screen:\n%s" % e,
                MessageBox.TYPE_ERROR,
                timeout=4,
            )

    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()


# ---------- plugin entry points ----------

def sessionstart(*args, **kwargs):
    session = None
    if args:
        first = args[0]
        if isinstance(first, int):
            reason = first
            print("[FuryEpg] sessionstart (reason %s)" % (reason,))
            if len(args) > 1:
                session = args[1]
        else:
            session = first
    else:
        session = kwargs.get("session")

    if session is None:
        print("[FuryEpg] sessionstart: NO SESSION, controller not created")
        return

    try:
        FuryEpgController(session)
        print("[FuryEpg] Controller created from sessionstart")
    except Exception as e:
        print("[FuryEpg] ERROR creating Controller: %s" % e)


def main(session, **kwargs):
    try:
        session.open(FuryEpgSetup)
    except Exception as e:
        print("[FuryEpg] ERROR opening setup: %s" % e)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="FuryEpg",
            description="FuryEpg - EPGTranslation",
            icon="furyepg.png",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart,
        ),
    ]
