# -*- coding: utf-8 -*-
# It was programmed by Islam Salama for Skin Fury  1/12/2025.

from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eEPGCache

# نستخدم إعدادات FuryEpg + الكنترولر لو موجود
try:
    from Components.config import config
    from Plugins.Extensions.FuryEpg.plugin import FuryEpgController
except Exception:
    config = None
    FuryEpgController = None


class FuryEpgEvent(Converter, object):
    NAME = 0
    DESCRIPTION = 1
    FULL = 2  # FullDescription

    def __init__(self, type):
        Converter.__init__(self, type)
        t = (type or "").strip()
        if t == "Name":
            self.type = self.NAME
        elif t == "Description":
            self.type = self.DESCRIPTION
        else:
            self.type = self.FULL

    @cached
    def getText(self):
        event = getattr(self.source, "event", None)

        if event is None:
            service = getattr(self.source, "service", None)
            if service is not None:
                try:
                    epgcache = eEPGCache.getInstance()
                    event = epgcache.lookupEventTime(service, -1)
                except Exception:
                    event = None

        if event is None:
            return ""

        name = event.getEventName() or ""
        short = event.getShortDescription() or ""
        ext = event.getExtendedDescription() or ""

        if not (name or short or ext):
            return ""

        desc_parts = [p for p in (short, ext) if p]
        desc_text = "\n".join(desc_parts).strip()

        # الكنترولر
        ctrl = None
        try:
            if FuryEpgController is not None:
                ctrl = FuryEpgController.instance
        except Exception:
            ctrl = None

        # دالة تجيب من الكاش بس
        def _get_cached(text):
            if not text or ctrl is None or not getattr(ctrl, "enabled", False):
                return None
            try:
                lang = config.plugins.furyepg.language.value
            except Exception:
                lang = "ar"
            cache_key = "%s|%s" % (lang, text)
            return ctrl.cache.get(cache_key, None)

        # نجرب نجيب الترجمة من الكاش
        name_t = _get_cached(name) if name else None
        desc_t = _get_cached(desc_text) if desc_text else None

        # لو مفيش في الكاش → نشغل الترجمة في الخلفية
        if ctrl is not None and getattr(ctrl, "enabled", False):
            try:
                if name and name_t is None:
                    ctrl.translate_async(name)
                if desc_text and desc_t is None:
                    ctrl.translate_async(desc_text)
            except Exception as e:
                print("[FuryEpgEvent] translate_async error:", e)

        # اللي هنعرضه دلوقتي:
        # أول مرة: غالباً مافيش ترجمة → نعرض الأصل
        # بعد ما الكاش يتملي: نفس الكونفرت أو مرة تانية هيلاقي الترجمة ويعرضها
        if name_t is None:
            name_t = name
        if desc_t is None:
            desc_t = desc_text

        if self.type == self.NAME:
            return name_t or name

        if self.type == self.DESCRIPTION:
            return desc_t or name_t or name

        # FULL: اسم + وصف
        parts = []
        if name_t:
            parts.append(name_t)
        if desc_t:
            parts.append(desc_t)
        full = "\n".join(parts)
        if not full:
            full = name or desc_text
        return full

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)